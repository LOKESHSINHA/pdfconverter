import React, { useState } from 'react';
import { saveAs } from 'file-saver';
import { firestore } from "../firebase";
import 'firebase/firestore'; // Import the Firestore module
import './FileToPdfConverter.css'; // Import the custom CSS file
import { addDoc, collection } from 'firebase/firestore';

const FileToPdfConverter = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [convertedPdf, setConvertedPdf] = useState(null);
  const [pdfData, setPdfData] = useState(null);
  const [feedback, setFeedback] = useState('');

  const handleFileChange = (e) => {
    setSelectedFile(e.target.files[0]);
    setConvertedPdf(null); // Reset the converted PDF when a new file is selected
    setPdfData(null); // Reset the PDF data
  };

  const convertToPdf = () => {
    if (selectedFile) {
      console.log("Converting file to PDF:", selectedFile.name);
      // Perform the conversion logic here

      // Assuming you have the converted PDF as a Blob or File object
      const convertedPdfBlob = new Blob(['Converted PDF content'], { type: 'application/pdf' });
      setConvertedPdf(convertedPdfBlob);

      // Set the PDF data for display
      const data = {
        fileName: selectedFile.name,
        fileExtension: selectedFile.name.split('.').pop(),
        url: 'URL_TO_CONVERTED_PDF',
      };
      setPdfData(data);
    } else {
      console.log("No file selected.");
    }
  };

  const handleFeedbackSubmit = () => {
    // Upload feedback to Firestore
    const collectionRef = collection(firestore, "feedback");
    const feedbackData = {
      feedback: feedback
    };
    addDoc(collectionRef, feedbackData)
      .then(() => {
        console.log("Feedback submitted to Firestore:", feedbackData);
      })
      .catch((error) => {
        console.log("Error submitting feedback to Firestore:", error);
      });
  };

  const handleDownload = () => {
    if (convertedPdf) {
      saveAs(convertedPdf, 'converted.pdf');
    }
  };

  return (
    <div className="file-to-pdf-converter">
      <h1 className="converter-title">File to PDF Converter</h1>
      <input type="file" onChange={handleFileChange} />
      <button className="convert-button" onClick={convertToPdf}>Convert to PDF</button>
      {convertedPdf && (
        <div className="result-container">
          <button className="download-button" onClick={handleDownload}>Download PDF</button>
          {pdfData && (
            <div className="pdf-data-container">
              <h2>Converted PDF Data:</h2>
              <p>File Name: {pdfData.fileName}</p>
              <p>File Extension: {pdfData.fileExtension}</p>
              <p>URL: {pdfData.url}</p>
              <textarea
                placeholder="Enter feedback"
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
              />
              <button className="submit-button" onClick={handleFeedbackSubmit}>Submit Feedback</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default FileToPdfConverter;
