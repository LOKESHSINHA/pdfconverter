import React from 'react';
import FileToPdfConverter from './component/FileToPdfConverter';
import './App.css';
import Message from './component/message';
import convertToPdf from './component/sample';
import Navbar from './component/Navbar';


function App() {
  return (
    <div>
      <FileToPdfConverter/>
    </div>
  );
}

export default App;

