// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import {getFirestore} from "@firebase/firestore";

// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBaDkmcbwNrpAx7g4TiiHaQi6C9IEvh0c4",
  authDomain: "assessment-6330f.firebaseapp.com",
  projectId: "assessment-6330f",
  storageBucket: "assessment-6330f.appspot.com",
  messagingSenderId: "174503882439",
  appId: "1:174503882439:web:3dedcc4e4f0661217358e2",
  measurementId: "G-ELF36WRM80"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const firestore =getFirestore(app);
